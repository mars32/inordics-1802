<template>

    <div class="tile" :style="{height}">

        <img v-if="!!img" :src="img"/>

        <div class="tile_body">
            <div class="title" v-if="!!title">{{ title }}</div>
            <div class="sub_title" v-if="!!subtitle">{{ subtitle }}</div>
        </div>
    </div>

</template>

<script>
    export default {
        name: "Tile",
        props: {
            height: {
                type: String,
                default: '200px'
            },
            title: {
                type: String,
                required: false
            },
            subtitle: {
                type: String,
                required: false
            },
            img: {
                type: String,
                required: false
            }
        }
    }
</script>

<style scoped>

    .tile {
        width: 25%;
        box-sizing: border-box;
        position: relative;
        display: flex;
        flex-direction: column;

        background-color: lightgrey;
        border: 1px solid black;
    }

    .tile_body{
        margin: auto 0;
        text-align: center;
    }

    img {
        position: absolute;
        width: 100%;
        height: 100%;
    }

</style>
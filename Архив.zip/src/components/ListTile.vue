<template>

    <div class="list">

        <Tile v-for="(i, id) in tiles"
              :key="`tile_${id}`"
              :height="i.height"
              :title="i.title"
              :subtitle="i.subtitle"
              :img="i.img">
        </Tile>

    </div>

</template>

<script>

    import Tile from './Tile';

    export default {
        name: "ListTile",
        components: {Tile},
        data(){

            return {
                tiles: [
                    {
                        title: 'Джинсовые куртки',
                        subtitle: 'от 3200руб',
                        height: '400px'
                    },
                    {
                        title: 'Элегантная обувь',
                        subtitle: 'ботинки, кроссовки'
                    },
                    {
                        title: 'Спортивная одежда',
                        subtitle: 'от 590руб'
                    },
                    {
                        title: 'Детская одежда'
                    },
                    {
                        subtitle: 'аксессуары'
                    },
                    {
                        title: 'Джинсы'
                    },
                ]
            };
        }
    }

</script>

<style scoped>

    .list{
        margin-top: 2rem;
        display: flex;
        flex-wrap: wrap;
    }

</style>